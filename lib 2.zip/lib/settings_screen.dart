import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:math';

import 'theme_notifier.dart';
import 'main.dart'; // scheduleAlarm 함수를 사용하기 위해 추가

class SettingScreen extends StatefulWidget {
  const SettingScreen({Key? key}) : super(key: key);

  @override
  _SettingScreenState createState() => _SettingScreenState();
}

class _SettingScreenState extends State<SettingScreen> {
  ThemeData? _selectedTheme;
  bool _isLoading = true;
  TimeOfDay _selectedTime = TimeOfDay(hour: 17, minute: 0);

  final List<ThemeData> _themes = [
    ThemeData(
      scaffoldBackgroundColor: Colors.white,
      primaryColor: Colors.blue,
      colorScheme: ColorScheme.fromSwatch().copyWith(secondary: Colors.orange),
      textTheme: const TextTheme(
        bodyLarge: TextStyle(color: Colors.blue),
        bodyMedium: TextStyle(color: Colors.black),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.blue,
        titleTextStyle: TextStyle(color: Colors.white, fontSize: 20),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: Colors.blue,
        selectedItemColor: Colors.orange,
        unselectedItemColor: Colors.white,
      ),
    ),
    ThemeData(
      scaffoldBackgroundColor: const Color(0xFFFFEBCD),
      primaryColor: const Color(0xFFFF6347),
      colorScheme:
          ColorScheme.fromSwatch().copyWith(secondary: const Color(0xFFFFD700)),
      textTheme: const TextTheme(
        bodyLarge: TextStyle(color: Color(0xFFFF6347)),
        bodyMedium: TextStyle(color: Color(0xFFFFA07A)),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFFFF6347),
        titleTextStyle: TextStyle(color: Colors.white, fontSize: 20),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: Color(0xFFFF6347),
        selectedItemColor: Color(0xFFFFD700),
        unselectedItemColor: Colors.white,
      ),
    ),
    ThemeData(
      scaffoldBackgroundColor: const Color(0xFFFAFAD2),
      primaryColor: const Color(0xFF00FA9A),
      colorScheme:
          ColorScheme.fromSwatch().copyWith(secondary: const Color(0xFF20B2AA)),
      textTheme: const TextTheme(
        bodyLarge: TextStyle(color: Color(0xFF00FA9A)),
        bodyMedium: TextStyle(color: Color(0xFF20B2AA)),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFF00FA9A),
        titleTextStyle: TextStyle(color: Colors.white, fontSize: 20),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: Color(0xFF00FA9A),
        selectedItemColor: Color(0xFF20B2AA),
        unselectedItemColor: Colors.white,
      ),
    ),
    ThemeData(
      scaffoldBackgroundColor: const Color(0xFFFFFACD),
      primaryColor: const Color(0xFFFFA07A),
      colorScheme:
          ColorScheme.fromSwatch().copyWith(secondary: const Color(0xFFFF4500)),
      textTheme: const TextTheme(
        bodyLarge: TextStyle(color: Color(0xFFFFA07A)),
        bodyMedium: TextStyle(color: Color(0xFFFF4500)),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFFFFA07A),
        titleTextStyle: TextStyle(color: Colors.white, fontSize: 20),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: Color(0xFFFFA07A),
        selectedItemColor: Color(0xFFFF4500),
        unselectedItemColor: Colors.white,
      ),
    ),
    ThemeData(
      scaffoldBackgroundColor: const Color(0xFFFFE4B5),
      primaryColor: const Color(0xFFCD853F),
      colorScheme:
          ColorScheme.fromSwatch().copyWith(secondary: const Color(0xFFD2691E)),
      textTheme: const TextTheme(
        bodyLarge: TextStyle(color: Color(0xFFCD853F)),
        bodyMedium: TextStyle(color: Color(0xFFD2691E)),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFFCD853F),
        titleTextStyle: TextStyle(color: Colors.white, fontSize: 20),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: Color(0xFFCD853F),
        selectedItemColor: Color(0xFFD2691E),
        unselectedItemColor: Colors.white,
      ),
    ),
    ThemeData(
      scaffoldBackgroundColor: const Color(0xFFF0F8FF),
      primaryColor: const Color(0xFF4682B4),
      colorScheme:
          ColorScheme.fromSwatch().copyWith(secondary: const Color(0xFF5F9EA0)),
      textTheme: const TextTheme(
        bodyLarge: TextStyle(color: Color(0xFF4682B4)),
        bodyMedium: TextStyle(color: Color(0xFF5F9EA0)),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFF4682B4),
        titleTextStyle: TextStyle(color: Colors.white, fontSize: 20),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: Color(0xFF4682B4),
        selectedItemColor: Color(0xFF5F9EA0),
        unselectedItemColor: Colors.white,
      ),
    ),
    ThemeData(
      scaffoldBackgroundColor: const Color(0xFFFFE4E1),
      primaryColor: const Color(0xFF8A2BE2),
      colorScheme:
          ColorScheme.fromSwatch().copyWith(secondary: const Color(0xFFFF69B4)),
      textTheme: const TextTheme(
        bodyLarge: TextStyle(color: Color(0xFF8A2BE2)),
        bodyMedium: TextStyle(color: Color(0xFFFF69B4)),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFF8A2BE2),
        titleTextStyle: TextStyle(color: Colors.white, fontSize: 20),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: Color(0xFF8A2BE2),
        selectedItemColor: Color(0xFFFF69B4),
        unselectedItemColor: Colors.white,
      ),
    ),
    ThemeData(
      scaffoldBackgroundColor: const Color(0xFFFFF5EE),
      primaryColor: const Color(0xFFFF7F50),
      colorScheme:
          ColorScheme.fromSwatch().copyWith(secondary: const Color(0xFF20B2AA)),
      textTheme: const TextTheme(
        bodyLarge: TextStyle(color: Color(0xFFFF7F50)),
        bodyMedium: TextStyle(color: Color(0xFF20B2AA)),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFFFF7F50),
        titleTextStyle: TextStyle(color: Colors.white, fontSize: 20),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: Color(0xFFFF7F50),
        selectedItemColor: Color(0xFF20B2AA),
        unselectedItemColor: Colors.white,
      ),
    ),
    ThemeData(
      scaffoldBackgroundColor: const Color(0xFFEEE8AA),
      primaryColor: const Color(0xFF9370DB),
      colorScheme:
          ColorScheme.fromSwatch().copyWith(secondary: const Color(0xFFE6E6FA)),
      textTheme: const TextTheme(
        bodyLarge: TextStyle(color: Color(0xFF9370DB)),
        bodyMedium: TextStyle(color: Color(0xFFE6E6FA)),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFF9370DB),
        titleTextStyle: TextStyle(color: Colors.white, fontSize: 20),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: Color(0xFF9370DB),
        selectedItemColor: Color(0xFFE6E6FA),
        unselectedItemColor: Colors.white,
      ),
    ),
    ThemeData(
      scaffoldBackgroundColor: const Color(0xFFFFFDD0),
      primaryColor: const Color(0xFFFFD700),
      colorScheme:
          ColorScheme.fromSwatch().copyWith(secondary: const Color(0xFFFF4500)),
      textTheme: const TextTheme(
        bodyLarge: TextStyle(color: Color(0xFFFFD700)),
        bodyMedium: TextStyle(color: Color(0xFFFF4500)),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFFFFD700),
        titleTextStyle: TextStyle(color: Colors.white, fontSize: 20),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: Color(0xFFFFD700),
        selectedItemColor: Color(0xFFFF4500),
        unselectedItemColor: Colors.white,
      ),
    ),
    ThemeData(
      scaffoldBackgroundColor: const Color(0xFFFFE5B4),
      primaryColor: const Color(0xFFFF6347),
      colorScheme:
          ColorScheme.fromSwatch().copyWith(secondary: const Color(0xFFFFA07A)),
      textTheme: const TextTheme(
        bodyLarge: TextStyle(color: Color(0xFFFF6347)),
        bodyMedium: TextStyle(color: Color(0xFFFFA07A)),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFFFF6347),
        titleTextStyle: TextStyle(color: Colors.white, fontSize: 20),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: Color(0xFFFF6347),
        selectedItemColor: Color(0xFFFFA07A),
        unselectedItemColor: Colors.white,
      ),
    ),
    ThemeData(
      scaffoldBackgroundColor: const Color(0xFFF5FFFA),
      primaryColor: const Color(0xFF98FF98),
      colorScheme:
          ColorScheme.fromSwatch().copyWith(secondary: const Color(0xFF3CB371)),
      textTheme: const TextTheme(
        bodyLarge: TextStyle(color: Color(0xFF98FF98)),
        bodyMedium: TextStyle(color: Color(0xFF3CB371)),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFF98FF98),
        titleTextStyle: TextStyle(color: Colors.white, fontSize: 20),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: Color(0xFF98FF98),
        selectedItemColor: Color(0xFF3CB371),
        unselectedItemColor: Colors.white,
      ),
    ),
    ThemeData(
      scaffoldBackgroundColor: const Color(0xFF87CEEB),
      primaryColor: const Color(0xFF00BFFF),
      colorScheme:
          ColorScheme.fromSwatch().copyWith(secondary: const Color(0xFF1E90FF)),
      textTheme: const TextTheme(
        bodyLarge: TextStyle(color: Color(0xFF00BFFF)),
        bodyMedium: TextStyle(color: Color(0xFF1E90FF)),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFF00BFFF),
        titleTextStyle: TextStyle(color: Colors.white, fontSize: 20),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: Color(0xFF00BFFF),
        selectedItemColor: Color(0xFF1E90FF),
        unselectedItemColor: Colors.white,
      ),
    ),
  ];

  @override
  void initState() {
    super.initState();
    _loadTheme();
    _loadSavedTime();
  }

  void _loadTheme() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool isClassicMode = prefs.getBool('isClassicMode') ?? true;
    setState(() {
      _selectedTheme = isClassicMode ? _themes[0] : ThemeData.light();
      _isLoading = false;
    });
  }

  void _loadSavedTime() async {
    final prefs = await SharedPreferences.getInstance();
    final hour = prefs.getInt('alarm_hour') ?? 17;
    final minute = prefs.getInt('alarm_minute') ?? 0;
    setState(() {
      _selectedTime = TimeOfDay(hour: hour, minute: minute);
    });
  }

  void _saveTime(TimeOfDay time) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('alarm_hour', time.hour);
    await prefs.setInt('alarm_minute', time.minute);
  }

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: _selectedTime,
    );
    if (picked != null && picked != _selectedTime) {
      setState(() {
        _selectedTime = picked;
      });
      _saveTime(picked);
      final now = DateTime.now();
      final scheduledTime =
          DateTime(now.year, now.month, now.day, picked.hour, picked.minute);
      scheduleAlarm(scheduledTime);
    }
  }

  void _toggleTheme() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      prefs.setBool('isClassicMode', true);
      _selectedTheme = _themes[0];
      _isLoading = false;
      final themeNotifier = Provider.of<ThemeNotifier>(context, listen: false);
      themeNotifier.setTheme(_selectedTheme!);
    });
  }

  void _randomTheme() {
    final random = Random();
    setState(() {
      _selectedTheme = _themes[random.nextInt(_themes.length)];
      _isLoading = false;
      final themeNotifier = Provider.of<ThemeNotifier>(context, listen: false);
      themeNotifier.setTheme(_selectedTheme!);
    });
  }

  void _changeTheme(ThemeData theme) {
    setState(() {
      _selectedTheme = theme;
      _isLoading = false;
      final themeNotifier = Provider.of<ThemeNotifier>(context, listen: false);
      themeNotifier.setTheme(_selectedTheme!);
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
        backgroundColor: _selectedTheme!.primaryColor,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              _selectedTheme!.primaryColor!,
              _selectedTheme!.colorScheme.secondary!,
              _selectedTheme!.scaffoldBackgroundColor!
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: ListView(
          children: [
            ListTile(
              title: Text('알람 시간 설정: ${_selectedTime.format(context)}'),
              onTap: () => _selectTime(context),
            ),
            ListTile(
              title: const Text('Random Theme'),
              onTap: _randomTheme,
            ),
            ListTile(
              title: const Text('Toggle Classic Theme'),
              onTap: _toggleTheme,
            ),
            ListTile(
              title: const Text('Sunset Theme'),
              onTap: () => _changeTheme(_themes[1]),
            ),
            ListTile(
              title: const Text('Spring Theme'),
              onTap: () => _changeTheme(_themes[2]),
            ),
            ListTile(
              title: const Text('Summer Theme'),
              onTap: () => _changeTheme(_themes[3]),
            ),
            ListTile(
              title: const Text('Autumn Theme'),
              onTap: () => _changeTheme(_themes[4]),
            ),
            ListTile(
              title: const Text('Winter Theme'),
              onTap: () => _changeTheme(_themes[5]),
            ),
            ListTile(
              title: const Text('Rainbow Theme'),
              onTap: () => _changeTheme(_themes[6]),
            ),
            ListTile(
              title: const Text('Coral Reef Theme'),
              onTap: () => _changeTheme(_themes[7]),
            ),
            ListTile(
              title: const Text('Lavender Fields Theme'),
              onTap: () => _changeTheme(_themes[8]),
            ),
            ListTile(
              title: const Text('Sunrise Theme'),
              onTap: () => _changeTheme(_themes[9]),
            ),
            ListTile(
              title: const Text('Peach Theme'),
              onTap: () => _changeTheme(_themes[10]),
            ),
            ListTile(
              title: const Text('Mint Theme'),
              onTap: () => _changeTheme(_themes[11]),
            ),
            ListTile(
              title: const Text('Sky Blue Theme'),
              onTap: () => _changeTheme(_themes[12]),
            ),
          ],
        ),
      ),
    );
  }
}
