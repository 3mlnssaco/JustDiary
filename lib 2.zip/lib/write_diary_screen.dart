import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:geolocator/geolocator.dart';
import 'package:uuid/uuid.dart';
import 'package:image_picker/image_picker.dart'; // 이미지 선택 패키지 추가
import 'diary.dart';

class WriteDiaryScreen extends StatefulWidget {
  const WriteDiaryScreen({super.key});

  @override
  _WriteDiaryScreenState createState() => _WriteDiaryScreenState();
}

class _WriteDiaryScreenState extends State<WriteDiaryScreen> {
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _contentController = TextEditingController();
  String _selectedFont = 'Roboto';
  double _fontSize = 16.0;
  DateTime _selectedDate = DateTime.now();
  String? _currentAddress;
  File? _selectedImage; // 선택한 이미지를 저장할 변수

  final ImagePicker _picker = ImagePicker(); // 이미지 선택기 인스턴스

  Future<void> _selectDateTime(BuildContext context) async {
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (pickedDate != null) {
      final TimeOfDay? pickedTime = await showTimePicker(
        context: context,
        initialTime: TimeOfDay.fromDateTime(_selectedDate),
      );
      if (pickedTime != null) {
        setState(() {
          _selectedDate = DateTime(
            pickedDate.year,
            pickedDate.month,
            pickedDate.day,
            pickedTime.hour,
            pickedTime.minute,
          );
        });
      }
    }
  }

  Future<void> _getCurrentLocation() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      return Future.error('Location services are disabled.');
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return Future.error('Location permissions are denied.');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      return Future.error(
          'Location permissions are permanently denied, we cannot request permissions.');
    }

    final Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
    setState(() {
      _currentAddress =
          'https://www.google.com/maps/search/?api=1&query=${position.latitude},${position.longitude}';
    });
  }

  Future<void> _pickImage() async {
    final XFile? pickedFile =
        await _picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _selectedImage = File(pickedFile.path);
      });
    }
  }

  void _saveDiary() async {
    try {
      var uuid = const Uuid();
      Diary newDiary = Diary(
        id: uuid.v4(), // 고유 ID 생성
        title: _titleController.text,
        content: _contentController.text,
        font: _selectedFont,
        fontSize: _fontSize,
        date: _selectedDate,
        location: _currentAddress, // 위치 정보 추가
        imagePath: _selectedImage?.path, // 이미지 경로 추가
      );

      Directory directory = await getApplicationDocumentsDirectory();
      File file = File('${directory.path}/diaries.json');

      List<Diary> diaries = [];
      if (await file.exists()) {
        String jsonString = await file.readAsString();
        List<dynamic> jsonList = json.decode(jsonString);
        diaries = jsonList.map((e) => Diary.fromJson(e)).toList();
      }

      // 새로운 일기를 기존 일기 목록에 추가
      diaries.add(newDiary);

      // 기존 파일을 덮어쓰는 대신 일기 목록 전체를 다시 저장
      await file
          .writeAsString(json.encode(diaries.map((e) => e.toJson()).toList()));

      // 저장 후 화면을 종료
      Navigator.pop(context, true);
    } catch (e) {
      print('Error saving diary: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('일기 작성'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            _showExitConfirmationDialog(context);
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.save),
            onPressed: _saveDiary,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _titleController,
              decoration: const InputDecoration(
                hintText: '제목',
              ),
            ),
            const SizedBox(height: 16.0),
            DropdownButtonFormField(
              value: _selectedFont,
              items: [
                'Roboto',
                '210 Ojunohwhoo L',
                '210 시골밥상L',
                'HGSS',
                'HoonSlimskinnyL',
                'SangSangFlowerRoad',
                'SangSangShinb7',
                'THE블랙잭L',
                'tvN Enjoystories Light',
                'Typo_CrayonM'
              ].map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  _selectedFont = value.toString();
                });
              },
            ),
            const SizedBox(height: 16.0),
            Row(
              children: [
                const Text('글자 크기: '),
                const SizedBox(width: 8.0),
                Expanded(
                  child: TextFormField(
                    initialValue: _fontSize.toString(),
                    keyboardType: TextInputType.number,
                    onChanged: (value) {
                      setState(() {
                        _fontSize = double.parse(value);
                      });
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16.0),
            Row(
              children: [
                const Text('작성 날짜 및 시간: '),
                const SizedBox(width: 8.0),
                Text(DateFormat('yyyy-MM-dd HH:mm').format(_selectedDate)),
                IconButton(
                  icon: const Icon(Icons.calendar_today),
                  onPressed: () => _selectDateTime(context),
                ),
              ],
            ),
            const SizedBox(height: 16.0),
            Row(
              children: [
                ElevatedButton(
                  onPressed: _getCurrentLocation,
                  child: const Text('위치 추가'),
                ),
                const SizedBox(width: 8.0),
                if (_currentAddress != null)
                  const Expanded(
                    child: Text(
                      '위치 추가됨',
                      style: TextStyle(color: Colors.green),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 16.0),
            if (_selectedImage != null)
              Column(
                children: [
                  Image.file(
                    _selectedImage!,
                    height: 200,
                    fit: BoxFit.cover,
                  ),
                  const SizedBox(height: 16.0),
                ],
              ),
            ElevatedButton(
              onPressed: _pickImage,
              child: const Text('사진 선택'),
            ),
            const SizedBox(height: 16.0),
            Expanded(
              child: TextField(
                controller: _contentController,
                decoration: const InputDecoration(
                  hintText: '일기 내용',
                ),
                maxLines: null,
                style: TextStyle(
                  fontSize: _fontSize,
                  fontFamily: _selectedFont,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _showExitConfirmationDialog(BuildContext context) async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('일기 작성 종료'),
          content: const SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                Text('작성 중인 일기가 저장되지 않습니다.'),
                Text('정말 종료하시겠습니까?'),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('아니오'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: const Text('예'),
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
}
