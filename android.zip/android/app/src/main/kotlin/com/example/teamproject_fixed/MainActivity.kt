package com.example.teamproject_fixed

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
