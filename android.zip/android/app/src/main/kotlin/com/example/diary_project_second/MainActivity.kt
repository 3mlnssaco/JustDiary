package com.example.diary_project_second

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
